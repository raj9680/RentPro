# StayNest UI templates (draft)

Static HTML templates for StayNest v1. Open `index.html` in a browser to reach every page.
No build step and no frameworks. Icons are inline SVG. Charts are drawn with SVG by `assets/js/common/charts.js`.

## Folder structure

```
staynest-ui/
  index.html                  Page index
  auth/                       login, register, change-password, logged-out
  owner/                      dashboard, properties, property-form, property-detail, space-status,
                              move-in, tenancies, tenancy-detail, invoices, inquiries,
                              reports-collections, reports-occupancy, account
  tenant/                     dashboard (my stay), invoices, documents, account
  admin/                      dashboard, owners, account
  public/                     search (vacancy search with inquiry form)
  errors/                     404, 403, 500
  assets/
    css/common/               variables.css (tokens), base.css, layout.css (app shell), components.css
    css/pages/                auth, dashboard, property-tree, space-status, move-in, search
    js/common/                app.js (sidebar, menus, modals, tabs, toasts, validation),
                              ajax.js (MVC Ajax helper with anti-forgery), charts.js
    js/pages/                 one script per page that needs behavior
```

## Moving into ASP.NET Core MVC

- Copy `assets/` into `wwwroot/`.
- The sidebar, top bar and script tags become `Views/Shared/_Layout.cshtml`, with the
  navigation in a partial per role (`_OwnerNav`, `_TenantNav`, `_AdminNav`).
- Auth pages use a separate `_AuthLayout.cshtml`.
- Each page's `<main class="content">` block becomes the view body. Page CSS and JS go in
  `@section Styles` and `@section Scripts`.
- Replace `<input name="__RequestVerificationToken" value="template-token">` with `@Html.AntiForgeryToken()`.
- Page scripts simulate server responses. Replace them with `StayNest.ajax` calls to your MVC controllers.
- Sample data (Sunrise Residency, Green Valley PG) matches the requirements document examples.
